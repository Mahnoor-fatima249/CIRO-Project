#!/bin/bash
# Run this script ONCE to download the real gradle-wrapper.jar
echo "Downloading gradle-wrapper.jar..."
curl -L "https://github.com/gradle/gradle/raw/v8.8.0/gradle/wrapper/gradle-wrapper.jar" \
     -o "$(dirname "$0")/gradle/wrapper/gradle-wrapper.jar"
echo "Done! gradle-wrapper.jar downloaded successfully."
