@echo off
@rem Gradle wrapper script for Windows — CIROApp
@rem Auto-downloads gradle-wrapper.jar if missing or invalid

setlocal

set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%
set WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar

@rem ─────────────────────────────────────────────────────────
@rem Auto-download real gradle-wrapper.jar if needed
@rem ─────────────────────────────────────────────────────────
if not exist "%WRAPPER_JAR%" goto downloadJar
for %%A in ("%WRAPPER_JAR%") do set JAR_SIZE=%%~zA
if %JAR_SIZE% LSS 10000 goto downloadJar
goto runGradle

:downloadJar
echo Downloading gradle-wrapper.jar...
set JAR_URL=https://github.com/gradle/gradle/raw/v8.8.0/gradle/wrapper/gradle-wrapper.jar
powershell -Command "Invoke-WebRequest -Uri '%JAR_URL%' -OutFile '%WRAPPER_JAR%'" 2>nul
if not exist "%WRAPPER_JAR%" (
    echo ERROR: Failed to download gradle-wrapper.jar
    echo Please download it manually from:
    echo %JAR_URL%
    exit /b 1
)
echo gradle-wrapper.jar downloaded successfully.

:runGradle
set DEFAULT_JVM_OPTS="-Xmx64m" "-Xms64m"
set APP_BASE_NAME=%~n0

if defined JAVA_HOME goto findJavaFromJavaHome
set JAVA_EXE=java.exe
%JAVA_EXE% -version >NUL 2>&1
if %ERRORLEVEL% equ 0 goto execute
echo ERROR: JAVA_HOME is not set and no 'java' command could be found.
goto fail

:findJavaFromJavaHome
set JAVA_HOME=%JAVA_HOME:"=%
set JAVA_EXE=%JAVA_HOME%/bin/java.exe
if exist "%JAVA_EXE%" goto execute
echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME%
goto fail

:execute
set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar
"%JAVA_EXE%" %DEFAULT_JVM_OPTS% %JAVA_OPTS% %GRADLE_OPTS% "-Dorg.gradle.appname=%APP_BASE_NAME%" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
if %ERRORLEVEL% neq 0 goto fail
goto end

:fail
exit /b 1
:end
endlocal
