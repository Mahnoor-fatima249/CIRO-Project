// ============================================================
// CIRO Utilities
// ============================================================

export const getSeverityColor = (severity) => {
  const map = {
    critical: "#FF2D55",
    high: "#FF9500",
    medium: "#FFCC00",
    low: "#34C759",
  };
  return map[severity] || "#8E8E93";
};

export const getSeverityBg = (severity) => {
  const map = {
    critical: "rgba(255,45,85,0.15)",
    high: "rgba(255,149,0,0.15)",
    medium: "rgba(255,204,0,0.15)",
    low: "rgba(52,199,89,0.15)",
  };
  return map[severity] || "rgba(142,142,147,0.15)";
};

export const getSignalIcon = (type) => {
  const map = {
    social: "💬",
    weather: "🌧️",
    traffic: "🚦",
    infrastructure: "🏗️",
    sensor: "📡",
  };
  return map[type] || "📌";
};

export const getResourceIcon = (type) => {
  const map = {
    rescue_team: "🚨",
    ambulance: "🚑",
    pump_truck: "🚒",
    police: "👮",
    helicopter: "🚁",
  };
  return map[type] || "🔧";
};

export const formatTimeAgo = (isoString) => {
  const diff = Date.now() - new Date(isoString).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
};

export const formatTime = (isoString) => {
  return new Date(isoString).toLocaleTimeString("en-PK", {
    hour: "2-digit",
    minute: "2-digit",
  });
};

export const getCrisisTypeLabel = (type) => {
  const map = {
    urban_flooding: "Urban Flooding",
    road_blockage: "Road Blockage",
    heatwave: "Heatwave",
    accident: "Accident",
    infrastructure_failure: "Infrastructure Failure",
  };
  return map[type] || type;
};

export const getCrisisTypeIcon = (type) => {
  const map = {
    urban_flooding: "🌊",
    road_blockage: "🚧",
    heatwave: "🌡️",
    accident: "💥",
    infrastructure_failure: "⚡",
  };
  return map[type] || "⚠️";
};

export const getStatusColor = (status) => {
  const map = {
    active: "#FF2D55",
    responding: "#FF9500",
    resolved: "#34C759",
    monitoring: "#007AFF",
  };
  return map[status] || "#8E8E93";
};

export const generateTicketId = () =>
  `CIRO-${Math.floor(100000 + Math.random() * 900000)}`;
