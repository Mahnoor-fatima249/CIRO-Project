// ============================================================
// CIRO — Crisis Detail Screen
// Full crisis analysis with real Gemini AI intelligence
// Tabs: Overview | AI Analysis | Response | Before/After | Logs
// ============================================================
import React, { useState, useRef, useEffect } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Animated, StatusBar, ActivityIndicator,
} from "react-native";
import { ActionService, MapsService, CrisisService } from "../services/apiServices";
import { getSeverityColor, getSeverityBg, getResourceIcon, formatTime, getCrisisTypeIcon } from "../utils/helpers";
import { EMERGENCY_RESOURCES, ALTERNATE_ROUTES } from "../data/mockData";

export default function CrisisDetailScreen({ route, navigation }) {
  const { crisis } = route.params;
  const [activeTab, setActiveTab] = useState("overview");
  const [executionLogs, setExecutionLogs] = useState([]);
  const [executingAction, setExecutingAction] = useState(null);
  const [showAfter, setShowAfter] = useState(false);
  const [actionsExecuted, setActionsExecuted] = useState([]);

  // AI Analysis state
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [aiAlert, setAiAlert] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAlertLoading, setAiAlertLoading] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 500, useNativeDriver: true }),
    ]).start();
  }, []);

  const executeAction = async (actionType, params = {}) => {
    if (actionsExecuted.includes(actionType)) return;
    setExecutingAction(actionType);
    try {
      let log;
      if (actionType === "dispatch") {
        log = await ActionService.dispatchEmergencyTeam(crisis.id, params.teamId || "res_001");
      } else if (actionType === "reroute") {
        log = await ActionService.rerouteTraffic(crisis.id, params.routeId || "route_001");
      } else if (actionType === "alert") {
        log = await ActionService.sendPublicAlert(
          crisis.id,
          `⚠️ ${crisis.title} — Please avoid the area. Alternate routes available.`,
          parseInt(crisis.affectedPeople?.replace(/[^0-9]/g, ""))
        );
      } else if (actionType === "ticket") {
        log = await ActionService.createEmergencyTicket(crisis.id, crisis.type);
      }
      if (log) {
        setExecutionLogs((prev) => [log, ...prev]);
        setActionsExecuted((prev) => [...prev, actionType]);
        if (actionsExecuted.length >= 1) setShowAfter(true);
      }
    } finally {
      setExecutingAction(null);
    }
  };

  const executeAll = async () => {
    await executeAction("ticket");
    await executeAction("alert");
    await executeAction("reroute", { routeId: "route_001" });
    await executeAction("dispatch", { teamId: "res_001" });
    setShowAfter(true);
  };

  const loadAIAnalysis = async () => {
    if (aiAnalysis || aiLoading) return;
    setAiLoading(true);
    try {
      const result = await CrisisService.analyzeCrisis(crisis);
      if (result.success) setAiAnalysis(result.analysis);
    } finally {
      setAiLoading(false);
    }
  };

  const loadAIAlert = async () => {
    if (aiAlert || aiAlertLoading) return;
    setAiAlertLoading(true);
    try {
      const result = await CrisisService.generateAlert(crisis);
      if (result) setAiAlert(result);
    } finally {
      setAiAlertLoading(false);
    }
  };

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "ai", label: "🤖 AI" },
    { id: "response", label: "Response" },
    { id: "before_after", label: "Before/After" },
    { id: "logs", label: "Logs" },
  ];

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A0A0F" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <View style={[styles.severityBadge, { backgroundColor: getSeverityBg(crisis.severity) }]}>
          <Text style={[styles.severityText, { color: getSeverityColor(crisis.severity) }]}>
            {crisis.severity.toUpperCase()}
          </Text>
        </View>
      </View>

      {/* Crisis Title */}
      <Animated.View style={[styles.titleSection, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
        <Text style={styles.crisisIcon}>{getCrisisTypeIcon(crisis.type)}</Text>
        <Text style={styles.crisisTitle}>{crisis.title}</Text>
        <Text style={styles.crisisLocation}>📍 {crisis.location.name}</Text>
        <View style={styles.metaRow}>
          <Text style={styles.metaItem}>👥 {crisis.affectedPeople}</Text>
          <Text style={styles.metaSep}>·</Text>
          <Text style={styles.metaItem}>🎯 {crisis.confidence}% confidence</Text>
          <Text style={styles.metaSep}>·</Text>
          <Text style={styles.metaItem}>📐 {crisis.affectedArea}</Text>
        </View>
      </Animated.View>

      {/* Tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabBar} contentContainerStyle={styles.tabBarContent}>
        {tabs.map((tab) => (
          <TouchableOpacity
            key={tab.id}
            style={[styles.tab, activeTab === tab.id && styles.tabActive]}
            onPress={() => {
              setActiveTab(tab.id);
              if (tab.id === "ai") { loadAIAnalysis(); loadAIAlert(); }
            }}
          >
            <Text style={[styles.tabText, activeTab === tab.id && styles.tabTextActive]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>

        {/* ── OVERVIEW TAB ── */}
        {activeTab === "overview" && (
          <View style={styles.tabContent}>
            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>🔍 Detected Situation</Text>
              <Text style={styles.infoText}>
                {crisis.title} with {crisis.confidence}% confidence. Multiple correlated signals detected from social media, weather data, and city sensors.
              </Text>
            </View>

            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>💥 Impact Assessment</Text>
              <View style={styles.impactRow}>
                <View style={styles.impactItem}>
                  <Text style={styles.impactLabel}>Affected People</Text>
                  <Text style={styles.impactValue}>{crisis.affectedPeople}</Text>
                </View>
                <View style={styles.impactItem}>
                  <Text style={styles.impactLabel}>Affected Area</Text>
                  <Text style={styles.impactValue}>{crisis.affectedArea}</Text>
                </View>
                <View style={styles.impactItem}>
                  <Text style={styles.impactLabel}>Confidence</Text>
                  <Text style={[styles.impactValue, { color: "#34C759" }]}>{crisis.confidence}%</Text>
                </View>
              </View>
            </View>

            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>⚡ Recommended Actions</Text>
              {[
                { icon: "🚨", text: "Dispatch emergency teams to affected area" },
                { icon: "🗺️", text: "Reroute traffic via alternate routes" },
                { icon: "📱", text: "Send public alert to affected users" },
                { icon: "📋", text: "Create emergency ticket for district officer" },
              ].map((a, i) => (
                <View key={i} style={styles.actionRow}>
                  <Text style={styles.actionIcon}>{a.icon}</Text>
                  <Text style={styles.actionText}>{a.text}</Text>
                </View>
              ))}
            </View>

            <TouchableOpacity style={styles.aiTabHint} onPress={() => { setActiveTab("ai"); loadAIAnalysis(); loadAIAlert(); }}>
              <Text style={styles.aiTabHintText}>🤖 View Gemini AI Deep Analysis →</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.executeAllBtn} onPress={executeAll}>
              <Text style={styles.executeAllText}>⚡ Execute All Actions</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── AI ANALYSIS TAB ── */}
        {activeTab === "ai" && (
          <View style={styles.tabContent}>

            {/* AI Powered badge */}
            <View style={styles.aiBadge}>
              <Text style={styles.aiBadgeIcon}>⚡</Text>
              <Text style={styles.aiBadgeText}>Powered by Google Gemini 2.0 Flash</Text>
            </View>

            {/* Crisis Deep Analysis */}
            <View style={styles.aiCard}>
              <Text style={styles.aiCardTitle}>🧠 AI Crisis Analysis</Text>
              {aiLoading ? (
                <View style={styles.aiLoading}>
                  <ActivityIndicator size="small" color="#007AFF" />
                  <Text style={styles.aiLoadingText}>Gemini is analyzing this crisis...</Text>
                </View>
              ) : aiAnalysis ? (
                <View>
                  <View style={styles.riskRow}>
                    <Text style={styles.riskLabel}>Risk Level</Text>
                    <View style={[styles.riskBadge, { backgroundColor: aiAnalysis.riskLevel === "extreme" ? "#FF2D5520" : "#FF950020" }]}>
                      <Text style={[styles.riskValue, { color: aiAnalysis.riskLevel === "extreme" ? "#FF2D55" : "#FF9500" }]}>
                        {aiAnalysis.riskLevel?.toUpperCase()}
                      </Text>
                    </View>
                  </View>

                  {aiAnalysis.immediateThreats?.length > 0 && (
                    <View style={styles.aiSection}>
                      <Text style={styles.aiSectionTitle}>⚠️ Immediate Threats</Text>
                      {aiAnalysis.immediateThreats.map((t, i) => (
                        <Text key={i} style={styles.aiListItem}>• {t}</Text>
                      ))}
                    </View>
                  )}

                  {aiAnalysis.recommendedActions?.length > 0 && (
                    <View style={styles.aiSection}>
                      <Text style={styles.aiSectionTitle}>⚡ AI Recommended Actions</Text>
                      {aiAnalysis.recommendedActions.map((a, i) => (
                        <View key={i} style={styles.aiActionItem}>
                          <View style={[styles.priorityTag, { backgroundColor: a.priority === "P1" ? "#FF2D5520" : a.priority === "P2" ? "#FF950020" : "#007AFF20" }]}>
                            <Text style={[styles.priorityText, { color: a.priority === "P1" ? "#FF2D55" : a.priority === "P2" ? "#FF9500" : "#007AFF" }]}>{a.priority}</Text>
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={styles.aiActionText}>{a.action}</Text>
                            {a.estimatedImpact && <Text style={styles.aiActionImpact}>{a.estimatedImpact}</Text>}
                          </View>
                        </View>
                      ))}
                    </View>
                  )}

                  <View style={styles.aiInfoRow}>
                    <Text style={styles.aiInfoLabel}>Est. Resolution</Text>
                    <Text style={styles.aiInfoValue}>{aiAnalysis.estimatedResolutionTime}</Text>
                  </View>

                  {aiAnalysis.publicGuidance && (
                    <View style={styles.guidanceBox}>
                      <Text style={styles.guidanceLabel}>📢 Public Guidance</Text>
                      <Text style={styles.guidanceText}>{aiAnalysis.publicGuidance}</Text>
                    </View>
                  )}

                  {aiAnalysis.escalationRequired && (
                    <View style={styles.escalationBanner}>
                      <Text style={styles.escalationText}>🚨 Escalation Required — Notify District Emergency Officer</Text>
                    </View>
                  )}
                </View>
              ) : (
                <TouchableOpacity style={styles.loadAIBtn} onPress={loadAIAnalysis}>
                  <Text style={styles.loadAIBtnText}>Tap to load AI analysis</Text>
                </TouchableOpacity>
              )}
            </View>

            {/* Bilingual Public Alert */}
            <View style={styles.aiCard}>
              <Text style={styles.aiCardTitle}>📢 AI-Generated Public Alert</Text>
              {aiAlertLoading ? (
                <View style={styles.aiLoading}>
                  <ActivityIndicator size="small" color="#FF9500" />
                  <Text style={styles.aiLoadingText}>Generating bilingual alert...</Text>
                </View>
              ) : aiAlert ? (
                <View>
                  <View style={styles.alertLangBox}>
                    <Text style={styles.alertLangLabel}>🇬🇧 English</Text>
                    <Text style={styles.alertLangText}>{aiAlert.englishAlert}</Text>
                  </View>
                  <View style={[styles.alertLangBox, { marginTop: 10 }]}>
                    <Text style={styles.alertLangLabel}>🇵🇰 اردو</Text>
                    <Text style={[styles.alertLangText, { textAlign: "right", fontFamily: "System" }]}>{aiAlert.urduAlert}</Text>
                  </View>

                  {aiAlert.doList?.length > 0 && (
                    <View style={styles.dosDonts}>
                      <View style={styles.doCol}>
                        <Text style={styles.doLabel}>✅ Do</Text>
                        {aiAlert.doList.map((d, i) => <Text key={i} style={styles.doItem}>• {d}</Text>)}
                      </View>
                      <View style={styles.doCol}>
                        <Text style={styles.dontLabel}>❌ Don't</Text>
                        {aiAlert.dontList?.map((d, i) => <Text key={i} style={styles.dontItem}>• {d}</Text>)}
                      </View>
                    </View>
                  )}

                  {aiAlert.helplineNumbers?.length > 0 && (
                    <View style={styles.helplineRow}>
                      <Text style={styles.helplineLabel}>📞 Helplines: </Text>
                      <Text style={styles.helplineNumbers}>{aiAlert.helplineNumbers.join("  |  ")}</Text>
                    </View>
                  )}
                </View>
              ) : (
                <TouchableOpacity style={styles.loadAIBtn} onPress={loadAIAlert}>
                  <Text style={styles.loadAIBtnText}>Tap to generate alert</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}

        {/* ── RESPONSE TAB ── */}
        {activeTab === "response" && (
          <View style={styles.tabContent}>
            <Text style={styles.subTitle}>Emergency Resources</Text>
            {EMERGENCY_RESOURCES.map((res) => (
              <View key={res.id} style={[styles.resourceCard, !res.available && styles.resourceUnavailable]}>
                <Text style={styles.resourceIcon}>{getResourceIcon(res.type)}</Text>
                <View style={styles.resourceInfo}>
                  <Text style={styles.resourceName}>{res.name}</Text>
                  <Text style={styles.resourceLocation}>📍 {res.location} · ETA: {res.eta}</Text>
                </View>
                <TouchableOpacity
                  style={[styles.dispatchBtn,
                    !res.available && styles.dispatchBtnDisabled,
                    actionsExecuted.includes("dispatch") && styles.dispatchBtnDone]}
                  disabled={!res.available || executingAction === "dispatch"}
                  onPress={() => executeAction("dispatch", { teamId: res.id })}
                >
                  <Text style={styles.dispatchBtnText}>
                    {!res.available ? "N/A" : actionsExecuted.includes("dispatch") ? "✓ Sent" : executingAction === "dispatch" ? "..." : "Dispatch"}
                  </Text>
                </TouchableOpacity>
              </View>
            ))}

            <Text style={[styles.subTitle, { marginTop: 20 }]}>Alternate Routes</Text>
            {ALTERNATE_ROUTES.map((route) => (
              <View key={route.id} style={styles.routeCard}>
                <View style={styles.routeInfo}>
                  <Text style={styles.routeName}>🗺️ {route.name}</Text>
                  <View style={styles.routeStats}>
                    <Text style={styles.routeStat}>⏱ +{route.estimatedDelay}</Text>
                    <Text style={styles.routeStat}>🚦 {route.trafficLevel}</Text>
                  </View>
                  <View style={styles.congestionBar}>
                    <View style={[styles.congestionFill, {
                      width: `${route.congestion}%`,
                      backgroundColor: route.congestion > 50 ? "#FF9500" : "#34C759"
                    }]} />
                  </View>
                  <Text style={styles.congestionLabel}>{route.congestion}% congestion</Text>
                </View>
                <TouchableOpacity
                  style={[styles.rerouteBtn, actionsExecuted.includes("reroute") && styles.rerouted]}
                  onPress={() => executeAction("reroute", { routeId: route.id })}
                  disabled={executingAction === "reroute"}
                >
                  <Text style={styles.rerouteBtnText}>
                    {actionsExecuted.includes("reroute") ? "✓ Active" : "Activate"}
                  </Text>
                </TouchableOpacity>
              </View>
            ))}

            <TouchableOpacity
              style={[styles.alertBtn, actionsExecuted.includes("alert") && styles.alertSent]}
              onPress={() => executeAction("alert")}
              disabled={executingAction === "alert" || actionsExecuted.includes("alert")}
            >
              <Text style={styles.alertBtnText}>
                {actionsExecuted.includes("alert") ? "✓ Alert Sent to 12,000 Users" : executingAction === "alert" ? "Sending..." : "📱 Send Public Alert"}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.ticketBtn, actionsExecuted.includes("ticket") && styles.ticketCreated]}
              onPress={() => executeAction("ticket")}
              disabled={executingAction === "ticket" || actionsExecuted.includes("ticket")}
            >
              <Text style={styles.ticketBtnText}>
                {actionsExecuted.includes("ticket") ? "✓ Emergency Ticket Created" : executingAction === "ticket" ? "Creating..." : "📋 Create Emergency Ticket"}
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── BEFORE/AFTER TAB ── */}
        {activeTab === "before_after" && (
          <View style={styles.tabContent}>
            <Text style={styles.beforeAfterNote}>
              {showAfter ? "✅ Actions executed — system state updated" : "Execute actions to see state change"}
            </Text>
            <View style={styles.stateGrid}>
              <View style={styles.stateColumn}>
                <View style={styles.stateHeader}>
                  <Text style={styles.stateHeaderText}>BEFORE</Text>
                  <Text style={styles.stateHeaderIcon}>🔴</Text>
                </View>
                {Object.entries(crisis.beforeState).map(([key, val]) => (
                  <View key={key} style={styles.stateRow}>
                    <Text style={styles.stateKey}>{key.replace(/([A-Z])/g, " $1").trim()}</Text>
                    <Text style={styles.stateValBefore}>{val}</Text>
                  </View>
                ))}
              </View>
              <View style={styles.arrowCol}>
                {Object.keys(crisis.beforeState).map((_, i) => (
                  <View key={i} style={styles.arrowWrap}>
                    <Text style={[styles.arrowText, showAfter && styles.arrowTextGreen]}>→</Text>
                  </View>
                ))}
              </View>
              <View style={styles.stateColumn}>
                <View style={[styles.stateHeader, { backgroundColor: "#34C75918" }]}>
                  <Text style={[styles.stateHeaderText, { color: "#34C759" }]}>AFTER</Text>
                  <Text style={styles.stateHeaderIcon}>🟢</Text>
                </View>
                {Object.entries(showAfter ? crisis.afterState : crisis.beforeState).map(([key, val]) => (
                  <View key={key} style={styles.stateRow}>
                    <Text style={styles.stateKey}>{key.replace(/([A-Z])/g, " $1").trim()}</Text>
                    <Text style={[styles.stateValAfter, !showAfter && { color: "#555" }]}>{val}</Text>
                  </View>
                ))}
              </View>
            </View>

            {!showAfter && (
              <TouchableOpacity style={styles.executeAllBtn} onPress={executeAll}>
                <Text style={styles.executeAllText}>⚡ Simulate All Actions to See Change</Text>
              </TouchableOpacity>
            )}

            {showAfter && (
              <View style={styles.outcomeCard}>
                <Text style={styles.outcomeTitle}>📊 Outcome Summary</Text>
                <Text style={styles.outcomeItem}>✅ Traffic rerouted — congestion reduced by ~65%</Text>
                <Text style={styles.outcomeItem}>✅ 3 emergency teams dispatched</Text>
                <Text style={styles.outcomeItem}>✅ 12,000 users alerted</Text>
                <Text style={styles.outcomeItem}>✅ Emergency ticket escalated to District Officer</Text>
                <Text style={styles.outcomeItem}>✅ Route updated for real-time users</Text>
              </View>
            )}
          </View>
        )}

        {/* ── LOGS TAB ── */}
        {activeTab === "logs" && (
          <View style={styles.tabContent}>
            <Text style={styles.subTitle}>Execution Logs</Text>
            {executionLogs.length === 0 ? (
              <View style={styles.emptyLogs}>
                <Text style={styles.emptyLogsIcon}>📋</Text>
                <Text style={styles.emptyLogsText}>No actions executed yet</Text>
                <Text style={styles.emptyLogsSub}>Go to Response tab and execute actions</Text>
              </View>
            ) : (
              executionLogs.map((log) => (
                <View key={log.id} style={styles.logCard}>
                  <View style={styles.logHeader}>
                    <View style={styles.logSuccessBadge}>
                      <Text style={styles.logSuccessText}>✓ SUCCESS</Text>
                    </View>
                    <Text style={styles.logTime}>{formatTime(log.timestamp)}</Text>
                  </View>
                  <Text style={styles.logAction}>{log.action.replace(/_/g, " ")}</Text>
                  <Text style={styles.logDetails}>{log.details}</Text>
                  {log.ticketId && (
                    <Text style={styles.logTicketId}>Ticket ID: {log.ticketId}</Text>
                  )}
                </View>
              ))
            )}
          </View>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0F" },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 20, paddingTop: 56, paddingBottom: 16 },
  backBtn: { padding: 4 },
  backText: { color: "#007AFF", fontSize: 15, fontWeight: "600" },
  severityBadge: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8 },
  severityText: { fontSize: 11, fontWeight: "900", letterSpacing: 1 },

  titleSection: { paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: "#1C1C2E" },
  crisisIcon: { fontSize: 36, marginBottom: 8 },
  crisisTitle: { fontSize: 22, fontWeight: "900", color: "#FFF", marginBottom: 4 },
  crisisLocation: { color: "#888", fontSize: 13, marginBottom: 10 },
  metaRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  metaItem: { color: "#555", fontSize: 12 },
  metaSep: { color: "#333" },

  tabBar: { maxHeight: 50 },
  tabBarContent: { paddingHorizontal: 16, paddingVertical: 10, gap: 6 },
  tab: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 8, backgroundColor: "#131318", alignItems: "center" },
  tabActive: { backgroundColor: "#007AFF" },
  tabText: { color: "#555", fontSize: 11, fontWeight: "600" },
  tabTextActive: { color: "#FFF" },

  content: { flex: 1 },
  tabContent: { padding: 16 },

  infoCard: { backgroundColor: "#131318", borderRadius: 14, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: "#1C1C2E" },
  infoTitle: { color: "#FFF", fontSize: 14, fontWeight: "700", marginBottom: 10 },
  infoText: { color: "#AAA", fontSize: 13, lineHeight: 20 },
  impactRow: { flexDirection: "row", justifyContent: "space-around" },
  impactItem: { alignItems: "center" },
  impactLabel: { color: "#555", fontSize: 10, marginBottom: 4 },
  impactValue: { color: "#FFF", fontSize: 16, fontWeight: "800" },
  actionRow: { flexDirection: "row", alignItems: "center", marginBottom: 8, gap: 10 },
  actionIcon: { fontSize: 16 },
  actionText: { color: "#CCC", fontSize: 13, flex: 1 },
  aiTabHint: { backgroundColor: "#007AFF15", borderRadius: 10, padding: 12, alignItems: "center", marginBottom: 10, borderWidth: 1, borderColor: "#007AFF33" },
  aiTabHintText: { color: "#007AFF", fontSize: 13, fontWeight: "600" },
  executeAllBtn: { backgroundColor: "#007AFF", borderRadius: 12, padding: 16, alignItems: "center", marginTop: 4 },
  executeAllText: { color: "#FFF", fontSize: 14, fontWeight: "700" },

  // AI Tab styles
  aiBadge: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 14 },
  aiBadgeIcon: { fontSize: 12 },
  aiBadgeText: { color: "#555", fontSize: 11 },
  aiCard: { backgroundColor: "#131318", borderRadius: 14, padding: 16, marginBottom: 14, borderWidth: 1, borderColor: "#1C1C2E" },
  aiCardTitle: { color: "#FFF", fontSize: 14, fontWeight: "700", marginBottom: 14 },
  aiLoading: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 8 },
  aiLoadingText: { color: "#555", fontSize: 13 },
  riskRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  riskLabel: { color: "#888", fontSize: 13 },
  riskBadge: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8 },
  riskValue: { fontSize: 12, fontWeight: "900", letterSpacing: 1 },
  aiSection: { marginBottom: 14 },
  aiSectionTitle: { color: "#888", fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 },
  aiListItem: { color: "#CCC", fontSize: 13, lineHeight: 20, marginBottom: 4 },
  aiActionItem: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 8 },
  priorityTag: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 5, marginTop: 1 },
  priorityText: { fontSize: 10, fontWeight: "900" },
  aiActionText: { color: "#CCC", fontSize: 13, marginBottom: 2 },
  aiActionImpact: { color: "#555", fontSize: 11 },
  aiInfoRow: { flexDirection: "row", justifyContent: "space-between", backgroundColor: "#0A0A0F", borderRadius: 8, padding: 10, marginBottom: 10 },
  aiInfoLabel: { color: "#555", fontSize: 12 },
  aiInfoValue: { color: "#FFF", fontSize: 12, fontWeight: "600" },
  guidanceBox: { backgroundColor: "#007AFF12", borderRadius: 10, padding: 12, borderWidth: 1, borderColor: "#007AFF25", marginBottom: 10 },
  guidanceLabel: { color: "#007AFF", fontSize: 11, fontWeight: "700", marginBottom: 6 },
  guidanceText: { color: "#AAA", fontSize: 13, lineHeight: 19 },
  escalationBanner: { backgroundColor: "#FF2D5518", borderRadius: 10, padding: 12, borderWidth: 1, borderColor: "#FF2D5533" },
  escalationText: { color: "#FF2D55", fontSize: 12, fontWeight: "700", textAlign: "center" },
  loadAIBtn: { backgroundColor: "#007AFF20", borderRadius: 8, padding: 12, alignItems: "center" },
  loadAIBtnText: { color: "#007AFF", fontSize: 13, fontWeight: "600" },
  alertLangBox: { backgroundColor: "#0A0A0F", borderRadius: 10, padding: 12 },
  alertLangLabel: { color: "#888", fontSize: 10, fontWeight: "700", marginBottom: 6, textTransform: "uppercase" },
  alertLangText: { color: "#CCC", fontSize: 13, lineHeight: 19 },
  dosDonts: { flexDirection: "row", gap: 10, marginTop: 12 },
  doCol: { flex: 1 },
  doLabel: { color: "#34C759", fontSize: 11, fontWeight: "700", marginBottom: 6 },
  doItem: { color: "#AAA", fontSize: 11, lineHeight: 17, marginBottom: 3 },
  dontLabel: { color: "#FF2D55", fontSize: 11, fontWeight: "700", marginBottom: 6 },
  dontItem: { color: "#AAA", fontSize: 11, lineHeight: 17, marginBottom: 3 },
  helplineRow: { flexDirection: "row", alignItems: "center", marginTop: 12, backgroundColor: "#0A0A0F", borderRadius: 8, padding: 10 },
  helplineLabel: { color: "#888", fontSize: 12 },
  helplineNumbers: { color: "#34C759", fontSize: 13, fontWeight: "700" },

  subTitle: { color: "#FFF", fontSize: 14, fontWeight: "700", marginBottom: 10 },
  resourceCard: { flexDirection: "row", backgroundColor: "#131318", borderRadius: 12, padding: 14, marginBottom: 8, alignItems: "center", borderWidth: 1, borderColor: "#1C1C2E" },
  resourceUnavailable: { opacity: 0.4 },
  resourceIcon: { fontSize: 22, marginRight: 12 },
  resourceInfo: { flex: 1 },
  resourceName: { color: "#FFF", fontSize: 13, fontWeight: "700", marginBottom: 3 },
  resourceLocation: { color: "#666", fontSize: 11 },
  dispatchBtn: { backgroundColor: "#FF2D5520", paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  dispatchBtnDisabled: { backgroundColor: "#1C1C2E" },
  dispatchBtnDone: { backgroundColor: "#34C75920" },
  dispatchBtnText: { color: "#FF2D55", fontSize: 11, fontWeight: "700" },
  routeCard: { flexDirection: "row", backgroundColor: "#131318", borderRadius: 12, padding: 14, marginBottom: 8, alignItems: "center", borderWidth: 1, borderColor: "#1C1C2E" },
  routeInfo: { flex: 1 },
  routeName: { color: "#FFF", fontSize: 13, fontWeight: "700", marginBottom: 6 },
  routeStats: { flexDirection: "row", gap: 12, marginBottom: 6 },
  routeStat: { color: "#666", fontSize: 11 },
  congestionBar: { height: 4, backgroundColor: "#1C1C2E", borderRadius: 2, marginBottom: 4 },
  congestionFill: { height: 4, borderRadius: 2 },
  congestionLabel: { color: "#555", fontSize: 10 },
  rerouteBtn: { backgroundColor: "#FF950020", paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8, marginLeft: 10 },
  rerouted: { backgroundColor: "#34C75920" },
  rerouteBtnText: { color: "#FF9500", fontSize: 11, fontWeight: "700" },
  alertBtn: { backgroundColor: "#FF9500", borderRadius: 12, padding: 16, alignItems: "center", marginTop: 12 },
  alertSent: { backgroundColor: "#34C75920", borderWidth: 1, borderColor: "#34C759" },
  alertBtnText: { color: "#FFF", fontSize: 14, fontWeight: "700" },
  ticketBtn: { backgroundColor: "#131318", borderRadius: 12, padding: 16, alignItems: "center", marginTop: 10, borderWidth: 1, borderColor: "#1C1C2E" },
  ticketCreated: { borderColor: "#34C759" },
  ticketBtnText: { color: "#CCC", fontSize: 14, fontWeight: "700" },

  beforeAfterNote: { color: "#888", fontSize: 12, textAlign: "center", marginBottom: 16, fontStyle: "italic" },
  stateGrid: { flexDirection: "row", marginBottom: 16 },
  stateColumn: { flex: 5 },
  arrowCol: { flex: 1, alignItems: "center" },
  stateHeader: { backgroundColor: "#FF2D5518", borderRadius: 8, padding: 8, marginBottom: 8, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  stateHeaderText: { color: "#FF2D55", fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  stateHeaderIcon: { fontSize: 12 },
  stateRow: { backgroundColor: "#131318", borderRadius: 8, padding: 10, marginBottom: 6, borderWidth: 1, borderColor: "#1C1C2E" },
  stateKey: { color: "#555", fontSize: 9, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 3 },
  stateValBefore: { color: "#FF6B6B", fontSize: 11, fontWeight: "600" },
  stateValAfter: { color: "#34C759", fontSize: 11, fontWeight: "600" },
  arrowWrap: { height: 52, justifyContent: "center" },
  arrowText: { color: "#555", fontSize: 16 },
  arrowTextGreen: { color: "#34C759" },
  outcomeCard: { backgroundColor: "#34C75912", borderRadius: 14, padding: 16, borderWidth: 1, borderColor: "#34C75933", marginTop: 8 },
  outcomeTitle: { color: "#34C759", fontSize: 14, fontWeight: "700", marginBottom: 10 },
  outcomeItem: { color: "#AAA", fontSize: 12, marginBottom: 6, lineHeight: 18 },

  emptyLogs: { alignItems: "center", paddingVertical: 40 },
  emptyLogsIcon: { fontSize: 40, marginBottom: 12 },
  emptyLogsText: { color: "#FFF", fontSize: 16, fontWeight: "700", marginBottom: 6 },
  emptyLogsSub: { color: "#555", fontSize: 13 },
  logCard: { backgroundColor: "#131318", borderRadius: 12, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: "#1C1C2E" },
  logHeader: { flexDirection: "row", justifyContent: "space-between", marginBottom: 6 },
  logSuccessBadge: { backgroundColor: "#34C75920", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 4 },
  logSuccessText: { color: "#34C759", fontSize: 9, fontWeight: "900" },
  logTime: { color: "#555", fontSize: 11 },
  logAction: { color: "#FFF", fontSize: 13, fontWeight: "700", marginBottom: 4 },
  logDetails: { color: "#888", fontSize: 12, lineHeight: 18 },
  logTicketId: { color: "#007AFF", fontSize: 11, marginTop: 4, fontWeight: "600" },
});
