// ============================================================
// CIRO — Signals Screen
// Full signal feed with filtering and processing
// ============================================================
import React, { useState, useEffect } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  TextInput, StatusBar, ActivityIndicator, Animated,
} from "react-native";
import { SignalService } from "../services/apiServices";
import { getSignalIcon, getSeverityColor, getSeverityBg, formatTimeAgo } from "../utils/helpers";

const FILTERS = ["All", "Social", "Weather", "Traffic", "Infrastructure"];

export default function SignalsScreen({ navigation }) {
  const [signals, setSignals] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [activeFilter, setActiveFilter] = useState("All");
  const [searchText, setSearchText] = useState("");
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(null);
  const [processedSignals, setProcessedSignals] = useState({});

  useEffect(() => {
    loadSignals();
  }, []);

  useEffect(() => {
    let result = signals;
    if (activeFilter !== "All") {
      result = result.filter((s) => s.type === activeFilter.toLowerCase());
    }
    if (searchText) {
      result = result.filter(
        (s) => s.content.toLowerCase().includes(searchText.toLowerCase()) ||
               s.source.toLowerCase().includes(searchText.toLowerCase())
      );
    }
    setFiltered(result);
  }, [activeFilter, searchText, signals]);

  const loadSignals = async () => {
    try {
      const data = await SignalService.fetchAllSignals();
      setSignals(data);
    } finally {
      setLoading(false);
    }
  };

  const processSignal = async (signal) => {
    setProcessing(signal.id);
    try {
      const result = await SignalService.processSignal(signal);
      setProcessedSignals((prev) => ({ ...prev, [signal.id]: result }));
    } finally {
      setProcessing(null);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Fetching signals...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A0A0F" />

      {/* Header */}
      <View style={styles.header}>
        {navigation.canGoBack() ? (
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={styles.backText}>← Back</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ width: 60 }} />
        )}
        <Text style={styles.headerTitle}>Signal Feed</Text>
        <View style={styles.signalCount}>
          <Text style={styles.signalCountText}>{signals.length}</Text>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="Search signals..."
          placeholderTextColor="#555"
          value={searchText}
          onChangeText={setSearchText}
        />
        {searchText.length > 0 && (
          <TouchableOpacity onPress={() => setSearchText("")}>
            <Text style={styles.clearSearch}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Filters */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll} contentContainerStyle={styles.filterContent}>
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.filterChip, activeFilter === f && styles.filterChipActive]}
            onPress={() => setActiveFilter(f)}
          >
            <Text style={[styles.filterText, activeFilter === f && styles.filterTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Signal Count */}
      <Text style={styles.resultCount}>{filtered.length} signals found</Text>

      {/* Signals List */}
      <ScrollView showsVerticalScrollIndicator={false}>
        {filtered.map((signal) => {
          const processed = processedSignals[signal.id];
          return (
            <View key={signal.id} style={styles.signalCard}>
              <View style={styles.signalHeader}>
                <Text style={styles.signalIcon}>{getSignalIcon(signal.type)}</Text>
                <View style={styles.signalMeta}>
                  <Text style={styles.signalSource}>{signal.source}</Text>
                  <Text style={styles.signalTime}>{formatTimeAgo(signal.timestamp)}</Text>
                </View>
                <View style={[styles.sevBadge, { backgroundColor: getSeverityBg(signal.severity) }]}>
                  <Text style={[styles.sevText, { color: getSeverityColor(signal.severity) }]}>
                    {signal.severity.toUpperCase()}
                  </Text>
                </View>
              </View>

              <Text style={styles.signalContent}>{signal.content}</Text>

              <View style={styles.signalFooter}>
                <Text style={styles.signalLocation}>📍 {signal.location?.name}</Text>
                <TouchableOpacity
                  style={[styles.processBtn, processed && styles.processBtnDone]}
                  onPress={() => processSignal(signal)}
                  disabled={processing === signal.id || !!processed}
                >
                  {processing === signal.id ? (
                    <ActivityIndicator size="small" color="#007AFF" />
                  ) : (
                    <Text style={[styles.processBtnText, processed && styles.processBtnTextDone]}>
                      {processed ? "✓ Processed" : "🔍 Process"}
                    </Text>
                  )}
                </TouchableOpacity>
              </View>

              {processed && (
                <View style={styles.processedResult}>
                  <View style={styles.processedRow}>
                    <Text style={styles.processedLabel}>Detected Type:</Text>
                    <Text style={styles.processedValue}>{processed.detectedType?.toUpperCase()}</Text>
                  </View>
                  <View style={styles.processedRow}>
                    <Text style={styles.processedLabel}>Confidence:</Text>
                    <Text style={[styles.processedValue, { color: "#34C759" }]}>{processed.confidenceScore}%</Text>
                  </View>
                  <View style={styles.processedRow}>
                    <Text style={styles.processedLabel}>Language:</Text>
                    <Text style={styles.processedValue}>{processed.language?.toUpperCase()}</Text>
                  </View>
                </View>
              )}
            </View>
          );
        })}
        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0F" },
  loadingContainer: { flex: 1, backgroundColor: "#0A0A0F", justifyContent: "center", alignItems: "center" },
  loadingText: { color: "#FFF", fontSize: 16, marginTop: 12 },

  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 56, paddingBottom: 16 },
  backText: { color: "#007AFF", fontSize: 15, fontWeight: "600" },
  headerTitle: { fontSize: 18, fontWeight: "800", color: "#FFF" },
  signalCount: { backgroundColor: "#FF2D55", width: 28, height: 28, borderRadius: 14, justifyContent: "center", alignItems: "center" },
  signalCountText: { color: "#FFF", fontSize: 12, fontWeight: "800" },

  searchContainer: { flexDirection: "row", alignItems: "center", backgroundColor: "#131318", borderRadius: 12, marginHorizontal: 16, marginBottom: 12, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1, borderColor: "#1C1C2E" },
  searchIcon: { fontSize: 14, marginRight: 8 },
  searchInput: { flex: 1, color: "#FFF", fontSize: 14 },
  clearSearch: { color: "#555", fontSize: 14, padding: 4 },

  filterScroll: { marginBottom: 8 },
  filterContent: { paddingHorizontal: 16, gap: 8 },
  filterChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: "#131318", borderWidth: 1, borderColor: "#1C1C2E" },
  filterChipActive: { backgroundColor: "#007AFF", borderColor: "#007AFF" },
  filterText: { color: "#555", fontSize: 12, fontWeight: "600" },
  filterTextActive: { color: "#FFF" },

  resultCount: { color: "#555", fontSize: 12, paddingHorizontal: 20, marginBottom: 12 },

  signalCard: { backgroundColor: "#131318", borderRadius: 14, marginHorizontal: 16, marginBottom: 10, padding: 14, borderWidth: 1, borderColor: "#1C1C2E" },
  signalHeader: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  signalIcon: { fontSize: 22, marginRight: 10 },
  signalMeta: { flex: 1 },
  signalSource: { color: "#007AFF", fontSize: 12, fontWeight: "700" },
  signalTime: { color: "#555", fontSize: 11, marginTop: 2 },
  sevBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  sevText: { fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  signalContent: { color: "#CCC", fontSize: 13, lineHeight: 19, marginBottom: 10 },
  signalFooter: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  signalLocation: { color: "#555", fontSize: 11, flex: 1 },
  processBtn: { backgroundColor: "#007AFF20", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  processBtnDone: { backgroundColor: "#34C75920" },
  processBtnText: { color: "#007AFF", fontSize: 11, fontWeight: "600" },
  processBtnTextDone: { color: "#34C759" },
  processedResult: { backgroundColor: "#0A0A0F", borderRadius: 8, padding: 10, marginTop: 10, gap: 4 },
  processedRow: { flexDirection: "row", justifyContent: "space-between" },
  processedLabel: { color: "#555", fontSize: 11 },
  processedValue: { color: "#FFF", fontSize: 11, fontWeight: "600" },
});
