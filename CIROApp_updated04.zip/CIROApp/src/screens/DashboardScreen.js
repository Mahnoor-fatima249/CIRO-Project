// ============================================================
// CIRO — Dashboard Screen
// Shows live crisis overview, weather, signal feed
// ============================================================
import React, { useState, useEffect } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  StatusBar, Animated, RefreshControl, ActivityIndicator,
} from "react-native";
import { CrisisService, WeatherService, SignalService } from "../services/apiServices";
import { getSeverityColor, getSeverityBg, getSignalIcon, formatTimeAgo, getCrisisTypeIcon, getStatusColor } from "../utils/helpers";

export default function DashboardScreen({ navigation }) {
  const [crises, setCrises] = useState([]);
  const [weather, setWeather] = useState(null);
  const [signals, setSignals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pulseAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    loadData();
    startPulse();
  }, []);

  const startPulse = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.3, duration: 800, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      ])
    ).start();
  };

  const loadData = async () => {
    try {
      const [crisesData, weatherData, signalsData] = await Promise.all([
        CrisisService.getActiveCrises(),
        WeatherService.getCurrentAlert(),
        SignalService.fetchAllSignals(),
      ]);
      setCrises(crisesData);
      setWeather(weatherData);
      setSignals(signalsData.slice(0, 4));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF2D55" />
        <Text style={styles.loadingText}>Initializing CIRO...</Text>
        <Text style={styles.loadingSubText}>Connecting to signal sources</Text>
      </View>
    );
  }

  const criticalCount = crises.filter((c) => c.severity === "critical").length;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A0A0F" />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>CIRO</Text>
          <Text style={styles.headerSub}>Crisis Intelligence & Response</Text>
        </View>
        <View style={styles.headerRight}>
          <Animated.View style={[styles.liveDot, { transform: [{ scale: pulseAnim }] }]} />
          <Text style={styles.liveText}>LIVE</Text>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#FF2D55" />}
      >
        {/* Alert Banner */}
        {criticalCount > 0 && (
          <View style={styles.alertBanner}>
            <Text style={styles.alertBannerIcon}>🚨</Text>
            <Text style={styles.alertBannerText}>
              {criticalCount} CRITICAL {criticalCount === 1 ? "CRISIS" : "CRISES"} ACTIVE — Response in Progress
            </Text>
          </View>
        )}

        {/* Weather Widget */}
        {weather && (
          <View style={styles.weatherCard}>
            <View style={styles.weatherLeft}>
              <Text style={styles.weatherIcon}>🌧️</Text>
              <View>
                <Text style={styles.weatherTemp}>{weather.temperature}°C</Text>
                <Text style={styles.weatherLocation}>{weather.location}</Text>
              </View>
            </View>
            <View style={styles.weatherRight}>
              <View style={styles.alertBadge}>
                <Text style={styles.alertBadgeText}>{weather.alertLevel?.toUpperCase()}</Text>
              </View>
              <Text style={styles.weatherAlert}>{weather.alert}</Text>
              <Text style={styles.weatherRainfall}>💧 {weather.rainfall}</Text>
            </View>
          </View>
        )}

        {/* Stats Row */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{crises.length}</Text>
            <Text style={styles.statLabel}>Active Crises</Text>
          </View>
          <View style={[styles.statCard, styles.statCardRed]}>
            <Text style={[styles.statNumber, { color: "#FF2D55" }]}>{criticalCount}</Text>
            <Text style={styles.statLabel}>Critical</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{signals.length}</Text>
            <Text style={styles.statLabel}>Signals</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={[styles.statNumber, { color: "#34C759" }]}>3</Text>
            <Text style={styles.statLabel}>Responding</Text>
          </View>
        </View>

        {/* Active Crises */}
        <Text style={styles.sectionTitle}>Active Crises</Text>
        {crises.map((crisis) => (
          <TouchableOpacity
            key={crisis.id}
            style={styles.crisisCard}
            onPress={() => navigation.navigate("CrisisDetail", { crisis })}
            activeOpacity={0.75}
          >
            <View style={styles.crisisCardTop}>
              <Text style={styles.crisisIcon}>{getCrisisTypeIcon(crisis.type)}</Text>
              <View style={styles.crisisInfo}>
                <Text style={styles.crisisTitle}>{crisis.title}</Text>
                <Text style={styles.crisisLocation}>📍 {crisis.location.name}</Text>
              </View>
              <View style={[styles.severityBadge, { backgroundColor: getSeverityBg(crisis.severity) }]}>
                <Text style={[styles.severityText, { color: getSeverityColor(crisis.severity) }]}>
                  {crisis.severity.toUpperCase()}
                </Text>
              </View>
            </View>

            <View style={styles.crisisStats}>
              <Text style={styles.crisisStat}>👥 {crisis.affectedPeople}</Text>
              <Text style={styles.crisisStat}>📐 {crisis.affectedArea}</Text>
              <Text style={styles.crisisStat}>🎯 {crisis.confidence}% confidence</Text>
            </View>

            <View style={styles.crisisCardBottom}>
              <View style={[styles.statusPill, { backgroundColor: getStatusColor(crisis.status) + "22" }]}>
                <View style={[styles.statusDot, { backgroundColor: getStatusColor(crisis.status) }]} />
                <Text style={[styles.statusText, { color: getStatusColor(crisis.status) }]}>
                  {crisis.status.toUpperCase()}
                </Text>
              </View>
              <Text style={styles.viewDetails}>View Details →</Text>
            </View>
          </TouchableOpacity>
        ))}

        {/* Signal Feed */}
        <View style={styles.signalHeader}>
          <Text style={styles.sectionTitle}>Live Signal Feed</Text>
          <TouchableOpacity onPress={() => navigation.navigate("Signals")}>
            <Text style={styles.seeAll}>See All</Text>
          </TouchableOpacity>
        </View>

        {signals.map((signal) => (
          <View key={signal.id} style={styles.signalCard}>
            <Text style={styles.signalIcon}>{getSignalIcon(signal.type)}</Text>
            <View style={styles.signalContent}>
              <View style={styles.signalMeta}>
                <Text style={styles.signalSource}>{signal.source}</Text>
                <Text style={styles.signalTime}>{formatTimeAgo(signal.timestamp)}</Text>
              </View>
              <Text style={styles.signalText} numberOfLines={2}>{signal.content}</Text>
              <View style={[styles.signalSeverity, { backgroundColor: getSeverityBg(signal.severity) }]}>
                <Text style={[styles.signalSeverityText, { color: getSeverityColor(signal.severity) }]}>
                  {signal.severity}
                </Text>
              </View>
            </View>
          </View>
        ))}

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.quickActions}>
          <TouchableOpacity style={[styles.quickBtn, { backgroundColor: "#FF2D5522" }]}
            onPress={() => crises.length > 0 && navigation.navigate("CrisisDetail", { crisis: crises[0] })}>
            <Text style={styles.quickBtnIcon}>⚡</Text>
            <Text style={[styles.quickBtnText, { color: "#FF2D55" }]}>Respond</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.quickBtn, { backgroundColor: "#007AFF22" }]}
            onPress={() => navigation.navigate("Agents")}>
            <Text style={styles.quickBtnIcon}>🤖</Text>
            <Text style={[styles.quickBtnText, { color: "#007AFF" }]}>Agent Trace</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.quickBtn, { backgroundColor: "#34C75922" }]}
            onPress={() => navigation.navigate("Signals")}>
            <Text style={styles.quickBtnIcon}>📡</Text>
            <Text style={[styles.quickBtnText, { color: "#34C759" }]}>Signals</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0F" },
  loadingContainer: { flex: 1, backgroundColor: "#0A0A0F", justifyContent: "center", alignItems: "center" },
  loadingText: { color: "#FFF", fontSize: 18, fontWeight: "700", marginTop: 16 },
  loadingSubText: { color: "#666", fontSize: 13, marginTop: 6 },

  header: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    paddingHorizontal: 20, paddingTop: 56, paddingBottom: 20,
    borderBottomWidth: 1, borderBottomColor: "#1C1C2E",
  },
  headerTitle: { fontSize: 28, fontWeight: "900", color: "#FFF", letterSpacing: 2 },
  headerSub: { fontSize: 11, color: "#666", marginTop: 2, letterSpacing: 1 },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 6 },
  liveDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#FF2D55" },
  liveText: { color: "#FF2D55", fontSize: 12, fontWeight: "800", letterSpacing: 2 },

  alertBanner: {
    flexDirection: "row", alignItems: "center",
    backgroundColor: "#FF2D5518", borderLeftWidth: 3, borderLeftColor: "#FF2D55",
    marginHorizontal: 16, marginTop: 16, paddingHorizontal: 16, paddingVertical: 12,
    borderRadius: 8, gap: 10,
  },
  alertBannerIcon: { fontSize: 18 },
  alertBannerText: { color: "#FF2D55", fontSize: 12, fontWeight: "700", flex: 1 },

  weatherCard: {
    flexDirection: "row", justifyContent: "space-between",
    backgroundColor: "#0F1729", borderRadius: 16, marginHorizontal: 16,
    marginTop: 16, padding: 16, borderWidth: 1, borderColor: "#1C2E4A",
  },
  weatherLeft: { flexDirection: "row", alignItems: "center", gap: 12 },
  weatherIcon: { fontSize: 32 },
  weatherTemp: { fontSize: 28, fontWeight: "800", color: "#FFF" },
  weatherLocation: { fontSize: 12, color: "#666" },
  weatherRight: { alignItems: "flex-end", flex: 1, paddingLeft: 12 },
  alertBadge: { backgroundColor: "#FF2D55", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 4, marginBottom: 4 },
  alertBadgeText: { color: "#FFF", fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  weatherAlert: { color: "#FF9500", fontSize: 11, fontWeight: "600", textAlign: "right", marginBottom: 4 },
  weatherRainfall: { color: "#007AFF", fontSize: 11 },

  statsRow: { flexDirection: "row", paddingHorizontal: 16, marginTop: 16, gap: 10 },
  statCard: {
    flex: 1, backgroundColor: "#131318", borderRadius: 12, paddingVertical: 14,
    alignItems: "center", borderWidth: 1, borderColor: "#1C1C2E",
  },
  statCardRed: { borderColor: "#FF2D5533" },
  statNumber: { fontSize: 24, fontWeight: "900", color: "#FFF" },
  statLabel: { fontSize: 10, color: "#555", marginTop: 2, textAlign: "center" },

  sectionTitle: { color: "#FFF", fontSize: 16, fontWeight: "800", paddingHorizontal: 16, marginTop: 24, marginBottom: 12, letterSpacing: 0.5 },

  crisisCard: {
    backgroundColor: "#131318", borderRadius: 16, marginHorizontal: 16,
    marginBottom: 12, padding: 16, borderWidth: 1, borderColor: "#1C1C2E",
  },
  crisisCardTop: { flexDirection: "row", alignItems: "flex-start", marginBottom: 12 },
  crisisIcon: { fontSize: 28, marginRight: 12 },
  crisisInfo: { flex: 1 },
  crisisTitle: { color: "#FFF", fontSize: 15, fontWeight: "700", marginBottom: 4 },
  crisisLocation: { color: "#666", fontSize: 12 },
  severityBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  severityText: { fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  crisisStats: { flexDirection: "row", gap: 12, marginBottom: 12 },
  crisisStat: { color: "#888", fontSize: 11 },
  crisisCardBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  statusPill: { flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, gap: 5 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 10, fontWeight: "700", letterSpacing: 1 },
  viewDetails: { color: "#007AFF", fontSize: 12, fontWeight: "600" },

  signalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, marginTop: 24, marginBottom: 12 },
  seeAll: { color: "#007AFF", fontSize: 13, fontWeight: "600" },

  signalCard: {
    flexDirection: "row", backgroundColor: "#131318", borderRadius: 12,
    marginHorizontal: 16, marginBottom: 8, padding: 14, borderWidth: 1, borderColor: "#1C1C2E",
    gap: 12,
  },
  signalIcon: { fontSize: 22 },
  signalContent: { flex: 1 },
  signalMeta: { flexDirection: "row", justifyContent: "space-between", marginBottom: 4 },
  signalSource: { color: "#007AFF", fontSize: 11, fontWeight: "600" },
  signalTime: { color: "#555", fontSize: 11 },
  signalText: { color: "#CCC", fontSize: 12, lineHeight: 17, marginBottom: 6 },
  signalSeverity: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  signalSeverityText: { fontSize: 9, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },

  quickActions: { flexDirection: "row", paddingHorizontal: 16, gap: 10 },
  quickBtn: { flex: 1, borderRadius: 12, paddingVertical: 16, alignItems: "center" },
  quickBtnIcon: { fontSize: 22, marginBottom: 6 },
  quickBtnText: { fontSize: 12, fontWeight: "700" },
});
