// ============================================================
// CIRO — Agent Trace Screen
// Shows Google Antigravity multi-agent reasoning steps
// ============================================================
import React, { useState, useEffect, useRef } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Animated, StatusBar, ActivityIndicator,
} from "react-native";
import { AntigravityService } from "../services/apiServices";

export default function AgentTraceScreen({ navigation }) {
  const [steps, setSteps] = useState([]);
  const [running, setRunning] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [summary, setSummary] = useState(null);
  const scrollRef = useRef();
  const progressAnim = useRef(new Animated.Value(0)).current;

  const runOrchestration = async () => {
    setRunning(true);
    setSteps([]);
    setCompleted(false);

    const sum = await AntigravityService.getWorkplanSummary();
    setSummary(sum);

    await AntigravityService.runFullOrchestration((completedSteps) => {
      setSteps([...completedSteps]);
      Animated.timing(progressAnim, {
        toValue: completedSteps.length / 6,
        duration: 400,
        useNativeDriver: false,
      }).start();
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    });

    setCompleted(true);
    setRunning(false);
  };

  useEffect(() => {
    runOrchestration();
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A0A0F" />

      {/* Header */}
      <View style={styles.header}>
        {navigation.canGoBack() ? (
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={styles.backText}>← Back</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ width: 60 }} />
        )}
        <Text style={styles.headerTitle}>Agent Trace</Text>
        <View style={styles.headerBadge}>
          <Text style={styles.headerBadgeText}>Antigravity</Text>
        </View>
      </View>

      {/* Workplan Summary */}
      {summary && (
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>🤖 Antigravity Orchestration</Text>
          <View style={styles.summaryRow}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{summary.totalAgents}</Text>
              <Text style={styles.summaryLabel}>Agents</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{summary.totalSteps}</Text>
              <Text style={styles.summaryLabel}>Steps</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{summary.estimatedTime}</Text>
              <Text style={styles.summaryLabel}>Total Time</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={[styles.summaryValue, { color: completed ? "#34C759" : "#FF9500", fontSize: 13 }]}>
                {completed ? "DONE" : "RUNNING"}
              </Text>
              <Text style={styles.summaryLabel}>Status</Text>
            </View>
          </View>

          {/* Progress Bar */}
          <View style={styles.progressBar}>
            <Animated.View style={[styles.progressFill, {
              width: progressAnim.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] })
            }]} />
          </View>
          <Text style={styles.progressLabel}>{steps.length}/6 steps completed</Text>
        </View>
      )}

      {/* Model Info */}
      <View style={styles.modelBadge}>
        <Text style={styles.modelIcon}>⚡</Text>
        <Text style={styles.modelText}>Powered by {summary?.model || "Google Antigravity + Gemini 2.5 Pro"}</Text>
      </View>

      <ScrollView ref={scrollRef} showsVerticalScrollIndicator={false} style={styles.stepsList}>
        <Text style={styles.stepsTitle}>Reasoning Steps</Text>

        {steps.map((step, index) => (
          <StepCard key={step.id} step={step} index={index} />
        ))}

        {running && steps.length < 6 && (
          <View style={styles.loadingStep}>
            <ActivityIndicator size="small" color="#007AFF" />
            <View style={styles.loadingStepText}>
              <Text style={styles.loadingStepTitle}>Processing next step...</Text>
              <Text style={styles.loadingStepSub}>Antigravity agent is reasoning</Text>
            </View>
          </View>
        )}

        {completed && (
          <View style={styles.completedCard}>
            <Text style={styles.completedIcon}>✅</Text>
            <Text style={styles.completedTitle}>Orchestration Complete</Text>
            <Text style={styles.completedSub}>All 6 agents executed successfully via Google Antigravity. Crisis response plan generated and executed.</Text>
          </View>
        )}

        {/* Decision Flow Diagram */}
        {completed && (
          <View style={styles.flowCard}>
            <Text style={styles.flowTitle}>📊 Decision Flow</Text>
            {[
              { label: "Signal Ingestion", icon: "📡", done: true },
              { label: "NLP Processing", icon: "🧠", done: true },
              { label: "Crisis Detection", icon: "🔍", done: true },
              { label: "Impact Analysis", icon: "📊", done: true },
              { label: "Action Planning", icon: "⚡", done: true },
              { label: "Execution", icon: "🚀", done: true },
            ].map((node, i, arr) => (
              <View key={i}>
                <View style={styles.flowNode}>
                  <View style={[styles.flowNodeDot, node.done && styles.flowNodeDotDone]}>
                    <Text style={styles.flowNodeIcon}>{node.icon}</Text>
                  </View>
                  <Text style={styles.flowNodeLabel}>{node.label}</Text>
                  {node.done && <Text style={styles.flowNodeCheck}>✓</Text>}
                </View>
                {i < arr.length - 1 && <View style={styles.flowConnector} />}
              </View>
            ))}
          </View>
        )}

        {completed && (
          <TouchableOpacity style={styles.rerunBtn} onPress={runOrchestration}>
            <Text style={styles.rerunBtnText}>🔄 Re-run Orchestration</Text>
          </TouchableOpacity>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

function StepCard({ step, index }) {
  const slideAnim = useRef(new Animated.Value(40)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(slideAnim, { toValue: 0, duration: 400, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
    ]).start();
  }, []);

  return (
    <Animated.View style={[styles.stepCard, { opacity: fadeAnim, transform: [{ translateX: slideAnim }] }]}>
      <View style={styles.stepLeft}>
        <View style={styles.stepDot} />
        {index < 5 && <View style={styles.stepLine} />}
      </View>
      <View style={styles.stepContent}>
        <View style={styles.stepHeader}>
          <Text style={styles.stepIcon}>{step.icon}</Text>
          <View style={styles.stepMeta}>
            <Text style={styles.stepAgent}>{step.agent}</Text>
            <Text style={styles.stepDuration}>⏱ {step.duration}</Text>
          </View>
          <View style={styles.stepStatus}>
            <Text style={styles.stepStatusText}>✓</Text>
          </View>
        </View>
        <Text style={styles.stepAction}>{step.action}</Text>
        <View style={styles.stepDetailBox}>
          <Text style={styles.stepDetail}>{step.detail}</Text>
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0F" },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 56, paddingBottom: 16 },
  backText: { color: "#007AFF", fontSize: 15, fontWeight: "600" },
  headerTitle: { fontSize: 17, fontWeight: "800", color: "#FFF" },
  headerBadge: { backgroundColor: "#007AFF", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  headerBadgeText: { color: "#FFF", fontSize: 10, fontWeight: "800" },

  summaryCard: { backgroundColor: "#0F1729", borderRadius: 16, marginHorizontal: 16, marginBottom: 12, padding: 16, borderWidth: 1, borderColor: "#1C2E4A" },
  summaryTitle: { color: "#FFF", fontSize: 14, fontWeight: "700", marginBottom: 12 },
  summaryRow: { flexDirection: "row", justifyContent: "space-around", marginBottom: 14 },
  summaryItem: { alignItems: "center" },
  summaryValue: { fontSize: 20, fontWeight: "900", color: "#007AFF", marginBottom: 2 },
  summaryLabel: { fontSize: 10, color: "#555" },
  progressBar: { height: 4, backgroundColor: "#1C1C2E", borderRadius: 2, marginBottom: 6 },
  progressFill: { height: 4, backgroundColor: "#007AFF", borderRadius: 2 },
  progressLabel: { color: "#555", fontSize: 11, textAlign: "center" },

  modelBadge: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, marginBottom: 12, gap: 6 },
  modelIcon: { fontSize: 12 },
  modelText: { color: "#555", fontSize: 11 },

  stepsList: { flex: 1, paddingHorizontal: 16 },
  stepsTitle: { color: "#FFF", fontSize: 15, fontWeight: "700", marginBottom: 16 },

  stepCard: { flexDirection: "row", marginBottom: 4 },
  stepLeft: { width: 24, alignItems: "center" },
  stepDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: "#007AFF", marginTop: 14 },
  stepLine: { flex: 1, width: 2, backgroundColor: "#1C1C2E", marginVertical: 4 },
  stepContent: { flex: 1, backgroundColor: "#131318", borderRadius: 12, padding: 14, marginLeft: 10, marginBottom: 10, borderWidth: 1, borderColor: "#1C1C2E" },
  stepHeader: { flexDirection: "row", alignItems: "flex-start", marginBottom: 6 },
  stepIcon: { fontSize: 20, marginRight: 8 },
  stepMeta: { flex: 1 },
  stepAgent: { color: "#007AFF", fontSize: 11, fontWeight: "700", marginBottom: 2 },
  stepDuration: { color: "#555", fontSize: 10 },
  stepStatus: { backgroundColor: "#34C75920", width: 22, height: 22, borderRadius: 11, justifyContent: "center", alignItems: "center" },
  stepStatusText: { color: "#34C759", fontSize: 11, fontWeight: "700" },
  stepAction: { color: "#FFF", fontSize: 13, fontWeight: "600", marginBottom: 8 },
  stepDetailBox: { backgroundColor: "#0A0A0F", borderRadius: 8, padding: 10 },
  stepDetail: { color: "#888", fontSize: 11, lineHeight: 17, fontFamily: "monospace" },

  loadingStep: { flexDirection: "row", alignItems: "center", backgroundColor: "#131318", borderRadius: 12, padding: 16, marginBottom: 10, gap: 12, borderWidth: 1, borderColor: "#007AFF33" },
  loadingStepText: { flex: 1 },
  loadingStepTitle: { color: "#007AFF", fontSize: 13, fontWeight: "600" },
  loadingStepSub: { color: "#555", fontSize: 11, marginTop: 2 },

  completedCard: { backgroundColor: "#34C75912", borderRadius: 14, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: "#34C75933", alignItems: "center" },
  completedIcon: { fontSize: 32, marginBottom: 10 },
  completedTitle: { color: "#34C759", fontSize: 16, fontWeight: "800", marginBottom: 8 },
  completedSub: { color: "#888", fontSize: 12, textAlign: "center", lineHeight: 18 },

  flowCard: { backgroundColor: "#131318", borderRadius: 14, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: "#1C1C2E" },
  flowTitle: { color: "#FFF", fontSize: 13, fontWeight: "700", marginBottom: 14 },
  flowNode: { flexDirection: "row", alignItems: "center", gap: 10 },
  flowNodeDot: { width: 36, height: 36, borderRadius: 18, backgroundColor: "#1C1C2E", justifyContent: "center", alignItems: "center" },
  flowNodeDotDone: { backgroundColor: "#007AFF20", borderWidth: 1, borderColor: "#007AFF" },
  flowNodeIcon: { fontSize: 16 },
  flowNodeLabel: { flex: 1, color: "#CCC", fontSize: 12, fontWeight: "600" },
  flowNodeCheck: { color: "#34C759", fontSize: 14, fontWeight: "700" },
  flowConnector: { width: 2, height: 14, backgroundColor: "#1C1C2E", marginLeft: 17, marginVertical: 2 },

  rerunBtn: { backgroundColor: "#131318", borderRadius: 12, padding: 14, alignItems: "center", marginBottom: 12, borderWidth: 1, borderColor: "#1C1C2E" },
  rerunBtnText: { color: "#007AFF", fontSize: 14, fontWeight: "600" },
});
