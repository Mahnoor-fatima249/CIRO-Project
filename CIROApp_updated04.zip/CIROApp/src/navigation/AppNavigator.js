// ============================================================
// CIRO — Navigation Setup
// React Navigation bottom tabs + stack
// ============================================================
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Text, View } from "react-native";

import DashboardScreen from "../screens/DashboardScreen";
import CrisisDetailScreen from "../screens/CrisisDetailScreen";
import AgentTraceScreen from "../screens/AgentTraceScreen";
import SignalsScreen from "../screens/SignalsScreen";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function TabIcon({ emoji, label, focused }) {
  return (
    <View style={{ alignItems: "center" }}>
      <Text style={{ fontSize: 20 }}>{emoji}</Text>
      <Text style={{ fontSize: 9, color: focused ? "#007AFF" : "#555", marginTop: 2, fontWeight: focused ? "700" : "400" }}>
        {label}
      </Text>
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: "#131318",
          borderTopColor: "#1C1C2E",
          borderTopWidth: 1,
          paddingBottom: 20,
          paddingTop: 10,
          height: 80,
        },
        tabBarShowLabel: false,
      }}
    >
      <Tab.Screen
        name="Dashboard"
        component={DashboardScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="🏠" label="Home" focused={focused} /> }}
      />
      <Tab.Screen
        name="Signals"
        component={SignalsScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="📡" label="Signals" focused={focused} /> }}
      />
      <Tab.Screen
        name="Agents"
        component={AgentTraceScreen}
        options={{ tabBarIcon: ({ focused }) => <TabIcon emoji="🤖" label="Agents" focused={focused} /> }}
      />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Main" component={MainTabs} />
        <Stack.Screen name="CrisisDetail" component={CrisisDetailScreen} />
        <Stack.Screen name="Response" component={CrisisDetailScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
