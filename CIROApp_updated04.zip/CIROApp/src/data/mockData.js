// ============================================================
// CIRO - Crisis Intelligence & Response Orchestrator
// Mock Data — simulates real-time APIs (Weather, Maps, Social)
// ============================================================

export const MOCK_SIGNALS = [
  {
    id: "sig_001",
    type: "social",
    source: "Twitter/X",
    content: "Flash flood happening at George Town for past 30 mins, roads completely blocked!",
    location: { lat: 24.8607, lng: 67.0011, name: "George Town, Karachi" },
    timestamp: new Date(Date.now() - 1800000).toISOString(),
    severity: "high",
    language: "en",
  },
  {
    id: "sig_002",
    type: "social",
    source: "WhatsApp Reports",
    content: "G-10 mein pani bhar gaya hai, gaariyan phans gayi hain, log madad maang rahe hain",
    location: { lat: 33.6844, lng: 73.0479, name: "G-10, Islamabad" },
    timestamp: new Date(Date.now() - 900000).toISOString(),
    severity: "critical",
    language: "urdu",
  },
  {
    id: "sig_003",
    type: "weather",
    source: "Weather API",
    content: "Heavy rainfall alert: 80mm expected in next 3 hours. Urban flooding risk HIGH.",
    location: { lat: 24.8607, lng: 67.0011, name: "Karachi Metro" },
    timestamp: new Date(Date.now() - 600000).toISOString(),
    severity: "high",
    language: "en",
  },
  {
    id: "sig_004",
    type: "traffic",
    source: "Google Maps API",
    content: "Traffic congestion spike detected: 340% above normal on M.A. Jinnah Road",
    location: { lat: 24.8607, lng: 67.0011, name: "MA Jinnah Road" },
    timestamp: new Date(Date.now() - 300000).toISOString(),
    severity: "medium",
    language: "en",
  },
  {
    id: "sig_005",
    type: "infrastructure",
    source: "City Sensors",
    content: "Storm drain overflow detected at 3 points. Pumping stations at 95% capacity.",
    location: { lat: 24.8607, lng: 67.0011, name: "Saddar, Karachi" },
    timestamp: new Date(Date.now() - 120000).toISOString(),
    severity: "critical",
    language: "en",
  },
];

export const MOCK_CRISIS_EVENTS = [
  {
    id: "evt_001",
    type: "urban_flooding",
    title: "Urban Flooding — George Town",
    location: { lat: 24.8607, lng: 67.0011, name: "George Town, Karachi" },
    severity: "critical",
    confidence: 94,
    affectedArea: "~3.2 km²",
    affectedPeople: "~12,000",
    status: "active",
    detectedAt: new Date(Date.now() - 1800000).toISOString(),
    signals: ["sig_001", "sig_003", "sig_005"],
    beforeState: {
      trafficFlow: "Normal",
      roadStatus: "Open",
      emergencyTeams: "At Base",
      alerts: "None Active",
    },
    afterState: {
      trafficFlow: "Rerouted via University Road",
      roadStatus: "Closed — Flooding",
      emergencyTeams: "3 Teams Dispatched",
      alerts: "12,000 Users Notified",
    },
  },
  {
    id: "evt_002",
    type: "road_blockage",
    title: "Road Blockage — MA Jinnah Road",
    location: { lat: 24.8502, lng: 67.0169, name: "MA Jinnah Road, Karachi" },
    severity: "high",
    confidence: 87,
    affectedArea: "~1.1 km",
    affectedPeople: "~4,500",
    status: "responding",
    detectedAt: new Date(Date.now() - 900000).toISOString(),
    signals: ["sig_004"],
    beforeState: {
      trafficFlow: "340% congested",
      roadStatus: "Partially Blocked",
      emergencyTeams: "Not Deployed",
      alerts: "None",
    },
    afterState: {
      trafficFlow: "Diverting via Shaheed-e-Millat",
      roadStatus: "Traffic Control Active",
      emergencyTeams: "1 Team En Route",
      alerts: "4,500 Users Notified",
    },
  },
];

export const EMERGENCY_RESOURCES = [
  { id: "res_001", type: "rescue_team", name: "Rescue Team Alpha", location: "Saddar HQ", available: true, eta: "8 min" },
  { id: "res_002", type: "rescue_team", name: "Rescue Team Bravo", location: "Gulshan Base", available: true, eta: "14 min" },
  { id: "res_003", type: "ambulance", name: "Ambulance Unit 7", location: "Civil Hospital", available: true, eta: "6 min" },
  { id: "res_004", type: "pump_truck", name: "Dewatering Truck 3", location: "KMC Depot", available: true, eta: "18 min" },
  { id: "res_005", type: "police", name: "Traffic Police Unit", location: "Saddar Station", available: false, eta: "N/A" },
];

export const ALTERNATE_ROUTES = [
  { id: "route_001", name: "University Road Bypass", status: "clear", trafficLevel: "low", estimatedDelay: "4 min extra", congestion: 22 },
  { id: "route_002", name: "Shaheed-e-Millat Expressway", status: "clear", trafficLevel: "medium", estimatedDelay: "7 min extra", congestion: 45 },
  { id: "route_003", name: "Korangi Industrial Route", status: "moderate", trafficLevel: "medium", estimatedDelay: "12 min extra", congestion: 58 },
];

export const AGENT_REASONING_STEPS = [
  {
    id: "step_1",
    agent: "Signal Collector Agent",
    icon: "📡",
    action: "Ingesting multi-source signals",
    detail: "Collected 5 signals from Twitter, WhatsApp, Weather API, Google Maps, City Sensors",
    status: "completed",
    duration: "1.2s",
  },
  {
    id: "step_2",
    agent: "NLP Processing Agent",
    icon: "🧠",
    action: "Processing Urdu/Roman Urdu text",
    detail: '"G-10 mein pani bhar gaya" → Event Type: Urban Flooding | Location: G-10 | Confidence: 94%',
    status: "completed",
    duration: "0.8s",
  },
  {
    id: "step_3",
    agent: "Crisis Detection Agent",
    icon: "🔍",
    action: "Clustering signals into crisis events",
    detail: "3 correlated signals → Urban Flooding confirmed at George Town. Severity: CRITICAL",
    status: "completed",
    duration: "1.5s",
  },
  {
    id: "step_4",
    agent: "Impact Analysis Agent",
    icon: "📊",
    action: "Estimating affected population & area",
    detail: "Affected area: 3.2 km² | Population at risk: ~12,000 | Infrastructure impact: HIGH",
    status: "completed",
    duration: "2.1s",
  },
  {
    id: "step_5",
    agent: "Action Planning Agent",
    icon: "⚡",
    action: "Generating coordinated response plan",
    detail: "Actions: Traffic rerouting + Emergency dispatch + Public alert + Pump trucks",
    status: "completed",
    duration: "1.8s",
  },
  {
    id: "step_6",
    agent: "Execution Agent (Antigravity)",
    icon: "🚀",
    action: "Simulating action execution via Antigravity",
    detail: "Route updated on Google Maps | 3 teams dispatched | 12,000 alerts sent | Tickets created",
    status: "completed",
    duration: "3.4s",
  },
];
