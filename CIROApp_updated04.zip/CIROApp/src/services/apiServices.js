// ============================================================
// CIRO Services — API Integration Layer
// Real: Google Gemini 2.0 Flash AI (NLP, Analysis, Orchestration)
// Simulated: Maps, Weather sensors (static city data)
// ============================================================

import {
  MOCK_SIGNALS,
  MOCK_CRISIS_EVENTS,
  EMERGENCY_RESOURCES,
  ALTERNATE_ROUTES,
  AGENT_REASONING_STEPS,
} from "../data/mockData";

import {
  processSignalWithGemini,
  analyzeCrisisWithGemini,
  runAgentStep,
  getWeatherIntelligence,
  generatePublicAlert,
} from "./GeminiService";

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

// ============================================================
// WEATHER SERVICE
// ============================================================
export const WeatherService = {
  async getCurrentAlert(location = "Karachi") {
    await delay(400);
    const weatherData = {
      location,
      temperature: 34,
      humidity: 88,
      rainfall: "80mm expected",
      windSpeed: "42 km/h",
      alert: "HEAVY RAINFALL — Urban Flooding Risk HIGH",
      alertLevel: "red",
      updatedAt: new Date().toISOString(),
    };
    try {
      const intelligence = await getWeatherIntelligence(weatherData);
      if (intelligence) return { ...weatherData, aiIntelligence: intelligence };
    } catch {}
    return weatherData;
  },

  async getRadarData() {
    await delay(400);
    return {
      rainfallZones: ["George Town", "Lyari", "Saddar", "Orangi"],
      intensity: "severe",
      movingDirection: "North-East",
      estimatedDuration: "3-4 hours",
    };
  },
};

// ============================================================
// MAPS SERVICE
// ============================================================
export const MapsService = {
  async getTrafficCongestion(location) {
    await delay(600);
    return {
      location,
      congestionLevel: 340,
      normalBaseline: 100,
      affectedRoads: ["MA Jinnah Road", "Shahrah-e-Faisal", "University Road"],
      hotspots: [
        { name: "George Town Crossing", delay: "45+ min" },
        { name: "Lyari Expressway Entry", delay: "28 min" },
        { name: "Saddar Junction", delay: "35 min" },
      ],
    };
  },

  async getAlternateRoutes(from, to) {
    await delay(800);
    return ALTERNATE_ROUTES;
  },

  async updateRoute(routeId, action) {
    await delay(500);
    return {
      success: true,
      routeId,
      action,
      timestamp: new Date().toISOString(),
      affectedUsers: Math.floor(Math.random() * 3000) + 1000,
      message: `Route ${action === "reroute" ? "updated" : "cleared"} successfully`,
    };
  },
};

// ============================================================
// SIGNAL SERVICE — Gemini NLP Processing
// ============================================================
export const SignalService = {
  async fetchAllSignals() {
    await delay(500);
    return MOCK_SIGNALS.map((s) => ({
      ...s,
      processedAt: new Date().toISOString(),
    }));
  },

  async processSignal(signal) {
    return await processSignalWithGemini(signal);
  },
};

// ============================================================
// CRISIS SERVICE — Gemini Deep Analysis
// ============================================================
export const CrisisService = {
  async detectCrises(signals) {
    await delay(800);
    return MOCK_CRISIS_EVENTS;
  },

  async getCrisisById(id) {
    await delay(200);
    return MOCK_CRISIS_EVENTS.find((e) => e.id === id) || null;
  },

  async getActiveCrises() {
    await delay(400);
    return MOCK_CRISIS_EVENTS.filter(
      (e) => e.status === "active" || e.status === "responding"
    );
  },

  async analyzeCrisis(crisis) {
    return await analyzeCrisisWithGemini(crisis);
  },

  async generateAlert(crisis) {
    return await generatePublicAlert(crisis);
  },
};

// ============================================================
// ACTION SERVICE
// ============================================================
export const ActionService = {
  executionLog: [],

  async dispatchEmergencyTeam(crisisId, teamId) {
    await delay(1200);
    const resource = EMERGENCY_RESOURCES.find((r) => r.id === teamId);
    const log = {
      id: `log_${Date.now()}`,
      action: "DISPATCH_EMERGENCY_TEAM",
      crisisId,
      resource: resource?.name || teamId,
      status: "success",
      timestamp: new Date().toISOString(),
      details: `${resource?.name || "Team"} dispatched. ETA: ${resource?.eta || "N/A"}. Unit tracking activated.`,
    };
    this.executionLog.push(log);
    return log;
  },

  async rerouteTraffic(crisisId, routeId) {
    await delay(1000);
    const route = ALTERNATE_ROUTES.find((r) => r.id === routeId);
    const result = await MapsService.updateRoute(routeId, "reroute");
    const log = {
      id: `log_${Date.now()}`,
      action: "REROUTE_TRAFFIC",
      crisisId,
      routeName: route?.name,
      status: "success",
      timestamp: new Date().toISOString(),
      details: `Traffic diverted via ${route?.name}. ~${result.affectedUsers.toLocaleString()} users notified.`,
    };
    this.executionLog.push(log);
    return log;
  },

  async sendPublicAlert(crisisId, message, affectedCount) {
    await delay(700);
    const log = {
      id: `log_${Date.now()}`,
      action: "SEND_PUBLIC_ALERT",
      crisisId,
      status: "success",
      timestamp: new Date().toISOString(),
      details: `Alert sent to ${affectedCount?.toLocaleString() || "12,000"} users via SMS + Push Notification.`,
      message,
    };
    this.executionLog.push(log);
    return log;
  },

  async createEmergencyTicket(crisisId, type) {
    await delay(500);
    const ticketId = `CIRO-${Date.now().toString().slice(-6)}`;
    const log = {
      id: `log_${Date.now()}`,
      action: "CREATE_EMERGENCY_TICKET",
      crisisId,
      ticketId,
      status: "success",
      timestamp: new Date().toISOString(),
      details: `Emergency ticket ${ticketId} created. Type: ${type}. Escalated to District Emergency Officer.`,
    };
    this.executionLog.push(log);
    return log;
  },

  getExecutionLog() {
    return this.executionLog;
  },
};

// ============================================================
// ANTIGRAVITY ORCHESTRATION — Real Gemini AI per step
// ============================================================
export const AntigravityService = {
  async runFullOrchestration(onStep) {
    const results = [];

    const orchestrationContext = {
      signalCount: MOCK_SIGNALS.length,
      sources: ["Twitter/X", "WhatsApp", "Weather API", "Google Maps", "City Sensors"],
      signalContent: MOCK_SIGNALS[1].content,
      crisisType: "Urban Flooding",
      location: "George Town, Karachi",
      affectedPeople: "~12,000",
      affectedArea: "3.2 km²",
    };

    for (let i = 0; i < AGENT_REASONING_STEPS.length; i++) {
      const baseStep = AGENT_REASONING_STEPS[i];
      const aiResult = await runAgentStep(baseStep.id, orchestrationContext);

      const completedStep = {
        ...baseStep,
        detail: aiResult.success ? aiResult.detail : baseStep.detail,
        aiPowered: aiResult.success,
        completedAt: new Date().toISOString(),
        status: "completed",
      };

      results.push(completedStep);
      if (onStep) onStep([...results]);
    }

    return results;
  },

  async getWorkplanSummary() {
    return {
      totalAgents: 6,
      totalSteps: AGENT_REASONING_STEPS.length,
      estimatedTime: "~12s",
      status: "ready",
      model: "Google Gemini 2.0 Flash",
    };
  },
};
