// ============================================================
// CIRO — Gemini AI Service
// Real Google Gemini 2.0 Flash API Integration
// Handles: NLP, Crisis Analysis, Action Planning, Orchestration
// ============================================================

const GEMINI_API_KEY = "AIzaSyBXgtH65wPlzvX7dHSoqWcZp6jp7WB4o2k";
const GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

// ─── Core API caller ─────────────────────────────────────────
async function callGemini(prompt, systemInstruction = null) {
  const body = {
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.3,
      maxOutputTokens: 1024,
    },
  };

  if (systemInstruction) {
    body.systemInstruction = { parts: [{ text: systemInstruction }] };
  }

  const response = await fetch(`${GEMINI_BASE_URL}?key=${GEMINI_API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err?.error?.message || `Gemini API error: ${response.status}`);
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error("Empty response from Gemini");
  return text.trim();
}

// ─── Parse JSON safely from Gemini response ──────────────────
function parseGeminiJSON(text) {
  try {
    // Remove markdown code fences if present
    const clean = text.replace(/```json\s*/gi, "").replace(/```\s*/gi, "").trim();
    return JSON.parse(clean);
  } catch {
    return null;
  }
}

// ============================================================
// 1. NLP SIGNAL PROCESSOR
//    Classifies signal type, detects language, extracts intent
// ============================================================
export async function processSignalWithGemini(signal) {
  const prompt = `Analyze this emergency/crisis signal text and return a JSON object.

Signal: "${signal.content}"
Source: ${signal.source}
Location: ${signal.location?.name || "Unknown"}

Return ONLY valid JSON with these exact fields:
{
  "detectedType": "flood|fire|accident|blockage|heatwave|infrastructure|unknown",
  "language": "en|urdu|roman_urdu|mixed",
  "confidenceScore": <integer 70-99>,
  "severity": "critical|high|medium|low",
  "keywords": ["word1", "word2"],
  "summary": "<one sentence English summary of the incident>",
  "urgency": "immediate|soon|monitor"
}`;

  try {
    const raw = await callGemini(prompt);
    const parsed = parseGeminiJSON(raw);
    if (!parsed) throw new Error("JSON parse failed");
    return {
      ...signal,
      detectedType: parsed.detectedType || "unknown",
      language: parsed.language || signal.language,
      confidenceScore: parsed.confidenceScore || 80,
      severity: parsed.severity || signal.severity,
      keywords: parsed.keywords || [],
      aiSummary: parsed.summary || signal.content,
      urgency: parsed.urgency || "monitor",
      processedByAI: true,
    };
  } catch (e) {
    // Graceful fallback: local processing
    return {
      ...signal,
      detectedType: "unknown",
      confidenceScore: 70,
      aiSummary: signal.content,
      processedByAI: false,
      aiError: e.message,
    };
  }
}

// ============================================================
// 2. CRISIS ANALYZER
//    Deep analysis of a detected crisis event
// ============================================================
export async function analyzeCrisisWithGemini(crisis) {
  const prompt = `You are a crisis response AI for Karachi, Pakistan. Analyze this crisis and return JSON.

Crisis: ${crisis.title}
Type: ${crisis.type}
Location: ${crisis.location?.name}
Severity: ${crisis.severity}
Affected People: ${crisis.affectedPeople}
Affected Area: ${crisis.affectedArea}

Return ONLY valid JSON:
{
  "riskLevel": "extreme|high|moderate|low",
  "immediateThreats": ["threat1", "threat2"],
  "recommendedActions": [
    { "action": "action description", "priority": "P1|P2|P3", "estimatedImpact": "description" }
  ],
  "estimatedResolutionTime": "e.g. 2-4 hours",
  "resourcesNeeded": ["resource1", "resource2"],
  "publicGuidance": "What should affected public do right now",
  "escalationRequired": true|false
}`;

  try {
    const raw = await callGemini(prompt);
    const parsed = parseGeminiJSON(raw);
    if (!parsed) throw new Error("JSON parse failed");
    return { success: true, analysis: parsed };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ============================================================
// 3. MULTI-AGENT ORCHESTRATOR
//    Runs Gemini through 6 reasoning steps sequentially
// ============================================================
const AGENT_SYSTEM = `You are an AI agent in CIRO — Crisis Intelligence & Response Orchestrator for Karachi, Pakistan. 
You analyze urban crises (floods, accidents, fires, blockages) and generate actionable response plans.
Be concise, specific, and data-driven. Always consider local context (Karachi geography, resources).`;

export async function runAgentStep(stepId, context) {
  const stepPrompts = {
    step_1: `You are the Signal Collector Agent.
Given these ${context.signalCount} signals from sources: ${context.sources?.join(", ")}.
Summarize what signals were collected and what initial patterns you observe.
Respond in 2-3 sentences, starting with "Collected ${context.signalCount} signals from..."`,

    step_2: `You are the NLP Processing Agent.
Analyze this signal content: "${context.signalContent}"
Identify: event type, location, severity, and language (English/Urdu/Roman Urdu).
Respond in 2-3 sentences with specific detected values.`,

    step_3: `You are the Crisis Detection Agent.
Based on correlated signals pointing to: ${context.crisisType} at ${context.location}.
Confirm the crisis, estimate confidence level (%), and state the primary risk.
Respond in 2-3 sentences with specific numbers.`,

    step_4: `You are the Impact Analysis Agent.
For ${context.crisisType} at ${context.location} affecting ~${context.affectedPeople} people in ${context.affectedArea}.
Estimate: infrastructure impact, secondary risks, and economic impact.
Respond in 2-3 specific sentences.`,

    step_5: `You are the Action Planning Agent.
For ${context.crisisType} at ${context.location}:
Generate a prioritized response plan with 4 specific actions (traffic, emergency teams, alerts, infrastructure).
Format: list 4 actions with P1/P2/P3 priority tags.`,

    step_6: `You are the Execution Agent.
All planned actions for ${context.crisisType} at ${context.location} are now executing.
Report execution status: traffic rerouted, teams dispatched, alerts sent, tickets created.
Include specific numbers (e.g. X users notified, Y teams deployed).
Respond as if reporting real-time execution results.`,
  };

  const prompt = stepPrompts[stepId] || `Analyze crisis step ${stepId} for ${context.location}`;

  try {
    const detail = await callGemini(prompt, AGENT_SYSTEM);
    return { success: true, detail };
  } catch (e) {
    return { success: false, detail: `Agent processing failed: ${e.message}` };
  }
}

// ============================================================
// 4. WEATHER INTELLIGENCE
//    Interprets weather data for crisis risk
// ============================================================
export async function getWeatherIntelligence(weatherData) {
  const prompt = `As a disaster risk AI for Karachi:
Temperature: ${weatherData.temperature}°C
Humidity: ${weatherData.humidity}%
Rainfall: ${weatherData.rainfall}
Wind: ${weatherData.windSpeed}

Return ONLY valid JSON:
{
  "floodRisk": "extreme|high|moderate|low",
  "affectedDistricts": ["district1", "district2"],
  "warningMessage": "one concise warning sentence for emergency responders",
  "recommendedPreparation": ["action1", "action2", "action3"]
}`;

  try {
    const raw = await callGemini(prompt);
    const parsed = parseGeminiJSON(raw);
    return parsed || null;
  } catch {
    return null;
  }
}

// ============================================================
// 5. PUBLIC ALERT GENERATOR
//    Generates bilingual alerts (English + Urdu)
// ============================================================
export async function generatePublicAlert(crisis) {
  const prompt = `Generate a brief public emergency alert for this crisis.

Crisis: ${crisis.title}
Location: ${crisis.location?.name}
Severity: ${crisis.severity}
Affected people: ${crisis.affectedPeople}

Return ONLY valid JSON:
{
  "englishAlert": "Brief English alert (max 2 sentences)",
  "urduAlert": "مختصر اردو الرٹ (زیادہ سے زیادہ 2 جملے)",
  "doList": ["do this", "do that"],
  "dontList": ["avoid this", "avoid that"],
  "helplineNumbers": ["1122", "115"]
}`;

  try {
    const raw = await callGemini(prompt);
    const parsed = parseGeminiJSON(raw);
    return parsed || null;
  } catch {
    return null;
  }
}
